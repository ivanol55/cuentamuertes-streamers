<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Muerte contabilizada</title>
		<meta name="author" content="ivanol55">
		<link rel="stylesheet" href="../css/style.css">
		<!--Devuelve al inicio a los 2 segundos en esta página-->
		<meta http-equiv="Refresh" content="2; url=../index.php" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<body>
		<h1>F. Volviendo al botón inicial</h1>
		<?php
			//Establece variables
			session_start();
			$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
			$dbUser = $ini_array["dbAccess"]["user"];
			$dbPassword = $ini_array["dbAccess"]["password"];
			$dbDatabase = $ini_array["dbAccess"]["database"];
			$dbHost = $ini_array["dbAccess"]["host"];
			$gameList = array();

			//Crea una array con todos los juegos en la tabla Juegos de la base de datos
			$query = "SELECT juego FROM juegos";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
				$gameList[] = $row;
				}
			
			//Fix por si caduca la sesión de PHP
			if (!isset($_SESSION["game"]) or !in_array($_SESSION["game"], $gameList)) {
				$game = end($gameList);
			} 
			else {
				$game = $_SESSION["game"];
			}
			//Inserta la entrada de muerte en la base de datos con la hora actual y los juegos y sesión recibidos por GET del formulario
			$date = date('Y-m-d H:i:s');
			$query = "INSERT INTO main(momento, sesion, juego) VALUES ('" . $date . "', " .$_GET["sesion"] . ", '" . $game . "')";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
		?>
	</body>
</html>
