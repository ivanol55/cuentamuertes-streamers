<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Administración de muertes</title>
		<meta name="author" content="ivanol55">
		<link rel="stylesheet" href="../css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php
			//Inicializa las variables
			$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
			$dbUser = $ini_array["dbAccess"]["user"];
			$dbPassword = $ini_array["dbAccess"]["password"];
			$dbDatabase = $ini_array["dbAccess"]["database"];
			$dbHost = $ini_array["dbAccess"]["host"];
			session_start();
			
			//Crea la lista de juegos que hay en la tabla Juegos
			$gameList = array();
			$query = "SELECT juego FROM juegos";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);

			//Fix por si caduca la sesión de php
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
				$gameList[] = $row;
				}
			if (!isset($_SESSION["game"]) or !in_array($_SESSION["game"], $gameList)) {
				$game = end($gameList);
			} 
			else {
				$game = $_SESSION["game"];
			}

			//Encuentra la última sesión jugada y la guarda en $sesion
			$query = "SELECT MAX(sesion) FROM main WHERE juego LIKE '" . $game . "'";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
					$sesion = $row;
				}
			?>
		</head>
		<body>
			<h1>Administración de muertes</h1>
			<h2>Panel de borrar muertes erróneas</h2>
			<!--Volver a la web principal-->
			<form action="../index.php">
				<input type="submit" value="Volver al inicio"></input>
			</form>
			<br>
			<!--Tabla de registros de muertes-->
			<table>
				<tr>
					<td>id</td><td>Se contó el</td><td>Sesión</td><td>Juego</td><td>BORRAR ENTRADA</td>
				</tr>
				<?php 
				//Pide todas las entradas de registro y las ordena por ID de mayor a menor
				$query = "SELECT * FROM main ORDER BY id DESC";
				$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);

				//Por cada entrada imprime en la tabla la id, la fecha y hora, la sesión, el juego y un botón para eliminarla
				while ($row = pg_fetch_row($result)) {
					echo "<tr>";
					echo "<td>" . $row[0] . "</td><td>" . $row[1] . "</td><td>" . $row[2] . "</td><td>" . $row[3] . "</td>";
					//El botón es un formulario que envía la ID de la entrada al formulario de eliminación.
					echo "<td> <form action=\"delete.php\"><input type=\"hidden\"  name=\"idBorrar\" value=\"" . $row[0] . "\"></input><input type=\"submit\" name=\"Eliminar entrada\" value=\"Eliminar entrada\"></input></form></td>";
					echo "</tr>";
				}?>
			</table>	
		</body>
	</html>
