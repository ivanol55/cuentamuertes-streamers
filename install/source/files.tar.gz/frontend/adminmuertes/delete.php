<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Muerte eliminada del registro</title>
		<meta name="author" content="ivanol55">
		<link rel="stylesheet" href="../css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="refresh" content="2;url='../index.php'">
		<?php
			//Declara variables
			$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
			$dbUser = $ini_array["dbAccess"]["user"];
			$dbPassword = $ini_array["dbAccess"]["password"];
			$dbDatabase = $ini_array["dbAccess"]["database"];
			$dbHost = $ini_array["dbAccess"]["host"];
			session_start();
			
			//Guarda todos los juegos de la tabla Juegos en un array
			$gameList = array();
			$query = "SELECT juego FROM juegos";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);

			//Fix por si caduca la sesión de PHP
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
				$gameList[] = $row;
				}
			if (!isset($_SESSION["game"]) or !in_array($_SESSION["game"], $gameList)) {
				$game = end($gameList);
			} 
			else {
				$game = $_SESSION["game"];
			}

			//Devuelve la última sesión jugada del juego seleccionado
			$query = "SELECT MAX(sesion) FROM main WHERE juego LIKE '" . $game . "'";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
					$sesion = $row;
				}
			?>
		</head>
		<body>
			<h1>Entrada borrada!</h1>
			<h2>Volviendo al inicio...</h2>
				<?php
				//Elimina la entrada con la ID recibida por GET de formulario
				$query = "DELETE FROM main WHERE main.id = " . $_GET["idBorrar"];
				$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);
				?>
			</table>	
		</body>
	</html>
