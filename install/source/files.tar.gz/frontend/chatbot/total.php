<?php 
session_start(); 
$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
//inicializa variables
$dbUser = $ini_array["dbAccess"]["user"];
$dbPassword = $ini_array["dbAccess"]["password"];
$dbDatabase = $ini_array["dbAccess"]["database"];
$dbHost = $ini_array["dbAccess"]["host"];
//Crea un array con todos los juegos existentes en la base de datos
$gameList = array();
$query = "SELECT juego FROM juegos";
$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
$result = pg_query($conn, $query);
while ($row = pg_fetch_row($result)) {
	$row = implode($row);
	$gameList[] = $row;
	}
//Si el juetgo que se pide en la request de API no está en la lista de juegos de la base de datos, devolverá un texto de error.
if (!in_array($_GET["game"], $gameList)) {
	echo "ERROR, ese juego no está en la lista de juegos posibles.";
	} 
//Si el juego pedido en la petición GET está en la lista de juegos disponibles, crear el texto de respuesta
else {
	//Encuentra el porcentaje de peso de las muertes del juego en el total de muertes general
	$game = $_GET["game"];
	$query = "SELECT (SELECT COUNT(*) FROM main WHERE juego LIKE '" . $game . "')::decimal / COUNT(*) * 100 AS porcentaje FROM main";
	$result = pg_query($conn, $query);
	while ($row = pg_fetch_row($result)) {
		$row = implode($row);
		$porcentaje = round(floatval($row), 2);
		}
	//Encuuentra el total de muertes de la última sesión registrada del juego que hemos pedido.
	$query = "SELECT COUNT(*) FROM main WHERE juego LIKE '" . $game . "' AND sesion = (SELECT MAX(sesion) FROM main WHERE juego LIKE '" . $game ."')";
	$result = pg_query($conn, $query);
	while ($row = pg_fetch_row($result)) {
		$row = implode($row);
		$muertesSesion = $row;
		}
	//Encuentra el total de muertes general del juego que se ha pedido, sin immportar sesión.
	$query = "SELECT COUNT(*) FROM MAIN WHERE JUEGO LIKE '" . $game . "'";
	$result = pg_query($conn, $query);
	while ($row = pg_fetch_row($result)) {
		$row = implode($row);
		//Imprime como respuesta un texto con los datos generados anteriormente.
		echo "tu streamer de confianza lleva " . $row . " muertes en " . $game . " (" . $muertesSesion . " muertes en la última sesión registrada), que representa un " . $porcentaje . "% de las muertes registradas.";
		}
	}
?>
