<?php 
//Establece el ini file de donde leer variables para el backend
session_start(); 
$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
//inicializa variables
$dbUser = $ini_array["dbAccess"]["user"];
$dbPassword = $ini_array["dbAccess"]["password"];
$dbDatabase = $ini_array["dbAccess"]["database"];
$dbHost = $ini_array["dbAccess"]["host"];
//Crea un listado de juegos y los mete en un string separado por comas.
$gameList = "";
$query = "SELECT juego FROM juegos";
$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
$result = pg_query($conn, $query);
while ($row = pg_fetch_row($result)) {
	$row = implode($row);
	$gameList = $gameList . $row . ",";
	}
//Devuelve del primer carácter al penúltimo del string, ya que el último es una coma.
echo substr($gameList, 0, -1);
?>
