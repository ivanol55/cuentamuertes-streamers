<!doctype html>
<html lang="es">
	<head>
		<?php 
		session_start(); 
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$title = $ini_array["customization"]["name"];
		?>
		<meta charset="utf-8">
		<title>Cuentamuertes de <?php echo $title;?></title>
		<meta name="author" content="ivanol55">
		<link rel="stylesheet" href="../css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php
			//Inicializar variables
			$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
			$dbUser = $ini_array["dbAccess"]["user"];
			$dbPassword = $ini_array["dbAccess"]["password"];
			$dbDatabase = $ini_array["dbAccess"]["database"];
			$dbHost = $ini_array["dbAccess"]["host"];
			session_start();
			$gameList = array();
			
			//Crea un array con todos los juegos que hay en la tabla Juegos de la base de datos
			$query = "SELECT juego FROM juegos";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
				$gameList[] = $row;
				}
			//Fix por si caduca la sesión de PHP
			if (!isset($_SESSION["game"]) or !in_array($_SESSION["game"], $gameList)) {
				$game = end($gameList);
			} 
			else {
				$game = $_SESSION["game"];
			}

			//Encuentra la última sesión jugada del juego establecido en la sesión
			$query = "SELECT MAX(sesion) FROM main WHERE juego LIKE '" . $game . "'";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
				$sesion = $row;
			}
		?>
	</head>
	<body>
		<h1>Salón de los logros</h1>
		<h2>Información de todo lo que llevas jugado</h2>
		<!--Contenedor inicial de Grid CSS-->
		<div class="grid-container">
			<!--Tabbla de total de muertes general-->
			<table class="grid-item">
				<tr>
					<td>
						Muertes totales entre todos los juegos: 
						<?php 
						//Encuentra el total general de muertes registradas y las imprime en un TD
						$query = "SELECT COUNT(*) FROM main";
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							echo $row[0];
							}
						?>
					</td>
				</tr>
			</table>
			<!--Tabla de canto porcentaje de muertes representa cada juego-->
			<table class="grid-item">
				<tr>
					<td>
						Porcentaje de las muertes totales por juego:<br><br>
						<?php 
						//Encuentra el nombre del juego, y el numero de muertes del juego dividido entre el total de muertes, para ponderarlo como porcentaje, y cada row la imprime en un td único. Se castea como decimal para que conserve decimales.
						$query = "SELECT main.juego, COUNT(*) / (SELECT COUNT(*) FROM main)::decimal * 100 AS porcentaje FROM main JOIN juegos ON main.juego = juegos.juego GROUP BY main.juego";
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							//Se redondea el resultado para evitar números muy largos
							echo $row[0] . " con un " . round($row[1], 2) . "% de las muertes" . "<br>";
							}
						?>
					</td>
				</tr>
			</table>
			<!--Tabla de juego o juegos con más muertes-->
			<table class="grid-item">
				<tr>
					<td>
						Juego o juegos con más muertes:<br><br>
						<?php 
						//Encuentra todos los juegos y cuantas muertes tienen, que sean iguales al máximo de muertes registradas en un juego.
						$query = "SELECT main.juego, COUNT(*) AS total FROM main GROUP BY main.juego HAVING count(*) = (SELECT COUNT(*) FROM main GROUP BY juego ORDER BY count(*) DESC LIMIT 1)";
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							echo $row[0] . " con " . $row[1] . " muertes" . "<br>";
							}
						?>
					</td>
				</tr>
			</table>
			<!--Tabla de juego o juegos con menos muertes-->
			<table class="grid-item">
				<tr>
					<td>
						Juego o juegos con menos muertes:<br><br>
						<?php 
						//Encuentra el nombre de los juegos y su numero de muertes que es igual al total de muertes mínimo registrado en la base de datos en un juego.
						$query = "SELECT main.juego, COUNT(*) AS total FROM main GROUP BY main.juego HAVING count(*) = (SELECT COUNT(*) FROM main GROUP BY juego ORDER BY count(*) ASC LIMIT 1)";
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							echo $row[0] . " con " . $row[1] . " muertes" . "<br>";
							}
						?>
					</td>
				</tr>
			</table>
			<!--Tabla de juego o juegos con mas peso de muertes totales en el porcentaje-->
			<table class="grid-item">
				<tr>
					<td>
						Juego o juegos con más peso en las muertes totales:<br><br>
						<?php 
						//Encuentra el juego o juegos con el porcentaje de muertes contribuido igual al del juego que más haya contribuido a esta cifra. Se castea como decimal para conservar decimales en el número.
						$query = "SELECT main.juego, COUNT(*) / (SELECT COUNT(*) FROM main)::decimal * 100 AS porcentaje FROM main JOIN juegos ON main.juego = juegos.juego GROUP BY main.juego HAVING COUNT(*) / (SELECT COUNT(*) FROM main)::decimal * 100 = (SELECT COUNT(*) / (SELECT COUNT(*) FROM main)::decimal * 100 AS porcentaje FROM main JOIN juegos ON main.juego = juegos.juego GROUP BY main.juego ORDER BY porcentaje DESC LIMIT 1)";
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							//Se redondea a 2 posiciones decimales para evitar números muy largos
							echo $row[0] . " con " . round($row[1], 2) . "% de muertes" . "<br>";
							}
						?>
					</td>
				</tr>
			</table>
			<!--Tabla de juego o juegos con menos peso para el porcentaje total de muertes-->
			<table class="grid-item">
				<tr>
					<td>
						Juego o juegos con menos peso en las muertes totales:<br><br>
						<?php 
						//Encuentra el nombre del juego o juegos y sus porcentajes de muertes ponderados que son iguales al procentaje ponderado de muertes por juego más bajo encontrado en la base de datos. Se castea como decimal para conservar los decimales del porcentaje con precisiónn
						$query = "SELECT main.juego, COUNT(*) / (SELECT COUNT(*) FROM main)::decimal * 100 AS porcentaje FROM main JOIN juegos ON main.juego = juegos.juego GROUP BY main.juego HAVING COUNT(*) / (SELECT COUNT(*) FROM main)::decimal * 100 = (SELECT COUNT(*) / (SELECT COUNT(*) FROM main)::decimal * 100 AS porcentaje FROM main JOIN juegos ON main.juego = juegos.juego GROUP BY main.juego ORDER BY porcentaje ASC LIMIT 1)";
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							//Se redondea la cifra resultante a 2 decimales para evitar cifras muy largas
							echo $row[0] . " con " . round($row[1], 2) . "% de muertes" . "<br>";
							}
						?>
					</td>
				</tr>
			</table>
		</div>
		<!--Botón para volver al inicio de la página-->
		<form action="../index.php">
			<input type="submit" value="Volver al inicio">
		</form>
	</body>
</html>
