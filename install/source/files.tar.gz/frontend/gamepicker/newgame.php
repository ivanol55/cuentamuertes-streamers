<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Juego insertado y establecido!</title>
		<meta name="author" content="ivanol55">
		<link rel="stylesheet" href="../css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!--Devuelve el usuario a la web principal tras 2 segundos en esta página-->
		<meta http-equiv="refresh" content="2; url=../">
	</head>
	<body>
		<h1>Juego creado!</h1>
		<h2>Volviendo al inicio con el juego elegido en 2 segundos...</h2>
			<?php
			//Establecer variables
			$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
			$dbUser = $ini_array["dbAccess"]["user"];
			$dbPassword = $ini_array["dbAccess"]["password"];
			$dbDatabase = $ini_array["dbAccess"]["database"];
			$dbHost = $ini_array["dbAccess"]["host"];
			session_start();

			//Inserta el juego recibido por medio de GET a la base de datos en la tabla Juegos para poder registrar muertes con él
			$query = "INSERT INTO juegos(juego) VALUES ('" . strval($_GET["game"]) . "')";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);

			//Establece el juego recién creado como activo
			$_SESSION["game"] = $_GET["game"];
			?>
	</body>
</html>
