<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Juego establecido!</title>
		<meta name="author" content="ivanol55">
		<link rel="stylesheet" href="../css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
			<meta http-equiv="refresh" content="2; url=../">
	</head>
	<body>
		<h1>Juego seleccionado!</h1>
		<h2>Volviendo al inicio con el juego elegido en 2 segundos...</h2>
			<?php
			session_start();
			//Establece el juego recibido por GET como ativo para registrar sus muertes en la base de datos.
			$_SESSION["game"] = $_GET["game"];
				?>
	</body>
</html>
