<!doctype html>
	<html lang="es">
		<?php 
		session_start(); 
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$title = $ini_array["customization"]["name"];
		?>
		<head>

			<meta charset="utf-8">
			<title>Cuentamuertes de <?php echo $title; ?></title>
			<meta name="author" content="ivanol55">
			<link rel="stylesheet" href="../css/style.css">
			<meta name="viewport" content="width=device-width, initial-scale=1">
		</head>
		<body>
			<h1>Selector y creador de juegos</h1>
			<h2>Crear un juego o elegir cuál vas a jugar hoy</h2>
			<br><br>
			<h3>Crear un juego posible</h3>
			<!--Este formulario envia un juego para que la base de datos lo cree como opción posible-->		
			<form action="newgame.php">
				<input type="text" name="game"><br><br>
				<input type="submit" value="Crear entrada de juego posible">
			</form>
			<br><br><br>
			<h4>En caso de que ya exista, entonces</h4>
			<br><br><br>
			<h3>A qué vas a jugar hoy?</h3>		
			<!--El segundo formulario permite cambiar el juego sobre el que se están registrando muertes-->
			<form action="pickgame.php">
				<!--Listado de juegos posibles que enviar al formulario de cambio-->
				<select name="game">
					<?php
					//Inicializar variables
					$dbUser = $ini_array["dbAccess"]["user"];
					$dbPassword = $ini_array["dbAccess"]["password"];
					$dbDatabase = $ini_array["dbAccess"]["database"];
					$dbHost = $ini_array["dbAccess"]["host"];

					//Devuelve un array de todos los juegos de la tabla Juegos. No se requiere DISTINCT porque el nombre del jeugo ya es la clave primaria.
					$query = "SELECT juego FROM juegos;";
					$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
					$result = pg_query($conn, $query);
					while ($row = pg_fetch_row($result)) {
						//Por cada entrada de la respuesta de la tabla de juegos se genera una entrada option para el formulario
						echo "<option value=\"" . $row[0] . "\">" . $row[0] . "</option>";
						}
					?>
				</select>
				<br><br>
				<input type="submit" value="Elegir juego del que contar muertes">
			</form>
	</body>
</html>
