<!doctype html>
<html lang="es">
	<head>
		<?php 
		session_start(); 
		$ini_array = parse_ini_file("../backend/creds/.my.cnf", true);
		$title = $ini_array["customization"]["name"];
		?>
		<meta charset="utf-8">
		<title>Cuentamuertes de <?php echo $title; ?></title>
		<meta name="author" content="ivanol55">
		<link rel="stylesheet" href="css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php
			//inicializa variables
			$dbUser = $ini_array["dbAccess"]["user"];
			$dbPassword = $ini_array["dbAccess"]["password"];
			$dbDatabase = $ini_array["dbAccess"]["database"];
			$dbHost = $ini_array["dbAccess"]["host"];

			//fix por si se caduca la sesión de juego, establece el juego como el ultimo insertado en la tabla Juegos
			$gameList = array();
			$query = "SELECT juego FROM juegos";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
				$gameList[] = $row;
				}
			if (!isset($_SESSION["game"]) or !in_array($_SESSION["game"], $gameList)) {
				$game = end($gameList);
			} 
			else {
				$game = $_SESSION["game"];
			}

			//encuentra la ultima sesion jugada del juego seleccionado y la guarda en $sesion
			$query = "SELECT MAX(sesion) FROM main WHERE juego LIKE '" . $game . "'";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$row = implode($row);
				$sesion = $row;
				}
			?>
		</head>
		<body>
	<br>
			<h1>Cuentamuertes de <?php echo $title; ?></h1>
			<h2>Contabilizar muerte</h2>
			<!--Elige el numero de sesion y contea una muerte en el contador-->
			<form action="contador/index.php">
				Sesión: <input type="number"  size="2" value=<?php echo "\"" . $sesion . "\""?> name="sesion"><br><br>
				<input type="submit" value="F, morición">
			</form><br>
			<!--LLeva al panel de estadísticas generales-->
			<form action="estadisticas/index.php">
				<input type="submit" value="Salón de las estadísticas">
			</form>
			<br>
			<!--Muestra el juego y sesión del que se están contando muertes-->
			<h4><?php echo "Juego actual: " . $game . " en la sesión de juego " . $sesion;?><form action="gamepicker/index.php"><input type="submit" value="Cambiar juego que contar"></form></h4>
		<!--Tabla principal de datos-->
		<table>
			<tr>
				<td>Muertes totales: 
				<?php
				//Cuenta las muertes totales del juego selecconado y las muestra en un td
				$query = "SELECT COUNT(*) FROM main WHERE juego LIKE '" . $game . "'";
				$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					$row = implode($row);
					echo ($row);
					$muertes = $row;
					}
				?>
				</td>
				<td>Última muerte: 
				<?php 
				//Encuentra la ultima muerte del juego seleccionado y la muestra en un td
				$query = "SELECT momento FROM main WHERE juego LIKE '" . $game . "' ORDER BY id DESC LIMIT 1";
				$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					$row = implode($row);
					echo ($row);
					}
				?>
				</td>
			</tr>
			<tr>
				<td>Muertes de media por hora: <?php 
				//Calcula media de muertes por hora del juego seleccionado y muestra la media en un td
				$query = "SELECT AVG(muertes) FROM (SELECT COUNT(*) as muertes FROM main WHERE juego LIKE '" . $game . "' GROUP BY date_trunc('hour', momento)) t";
			$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					$row = round(floatval(implode($row)), 2);
					echo $row;
					}
				?>
				</td>
				<td>Muertes de media por sesión: <?php 
				//Calcula muertes de media por sesion de juego del juego seleccionado y las muestra en un td
				$query = "SELECT AVG(muertes) FROM (SELECT COUNT(*) as muertes FROM main WHERE juego LIKE '" . $game . "' GROUP BY sesion) t";
				$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					$row = round(floatval(implode($row)), 2);
					echo $row;
					}
				?>
				</td>
			</tr>
			<tr>
				<td>Sesión con mas muertes: <?php 
				//sesion con mas muertes del juego seleccionado mostrada en un td
				$query = "SELECT sesion, COUNT(*) FROM main WHERE juego LIKE '" . $game ."' GROUP BY sesion ORDER BY COUNT(*) DESC LIMIT 1";
				$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					echo "Sesión " . $row[0] . " con " . $row[1] . " muertes.";
					}
				?>
				</td>
				<td>Sesión con menos muertes: <?php 
				//sesion con menos muertes del juego seleccionado mostrada en un td
				$query = "SELECT sesion, COUNT(*) FROM main WHERE juego LIKE '" . $game . "' GROUP BY sesion ORDER BY COUNT(*) ASC LIMIT 1";
				$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					echo "Sesión " . $row[0] . " con " . $row[1] . " muertes.";
					}
				?>
				
				</td>
			</tr>
			<tr>
				<?php
				//Muestra las muertes por sesión de forma individual.
				//Si la sesión es la 1a registrada, muestra solo una fila de 2 de ancho con los datos de muertes de esa primera sesión.
				if (intval($sesion) == 1) {
					echo "<td colspan=\"2\">";
						$query = "SELECT COUNT(*) FROM main WHERE juego LIKE '" . $game . "' AND sesion = " . $sesion;
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							echo $row[0] . " muertes en la sesión actual.";
					}
					echo "</td>";
				//Si hay más de una sesión, se crean dos cajas, una con las muertes de la sesión actual y una con las que se registraron en la sesión anterior, para comparar.
				} else {
					echo "<td>";
						$query = "SELECT COUNT(*) FROM main WHERE juego LIKE '" . $game . "' AND sesion = " . $sesion;
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							echo $row[0] . " muertes en la sesión actual.";
							}
					echo "</td>";
					echo "<td>";
						$query = "SELECT COUNT(*) FROM main WHERE juego LIKE '" . $game . "' AND sesion = " . (intval($sesion) - 1);
						$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							echo $row[0] . " muertes en la sesión anterior.";
							}
					echo "</td>";
					}
					?>
				</tr>
				</table>
				<!--Gráfica de muertes-->
				<h4>Gráfica de muertes (cada horizontal amarilla son 50)</h4>
				<?php
				//Devuelve un array de las muertes por día del juego elegido, ordenadas de más antigua a más reciente
				$deathArray = array();
				$query = "SELECT COUNT(*) FROM main WHERE juego LIKE '" . $game ."' GROUP BY sesion ORDER BY sesion ASC;";
					$conn = pg_pconnect("host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPassword);
					$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					$deathArray[] = implode($row);
					}
			//Genera un array con la progresión de muertes totales
			$aux = 0;
			$height = intval($muertes) + 5;
			$totalSums = array();
			foreach($deathArray as $sumar) {
				$aux = intval($aux) + intval($sumar);
				$totalSums[] = intval($height) - $aux;
				}
			//Genera el string para el polyline
			$stringPoly = "";
			$widthStart = 0;
			foreach($totalSums as $y) {
				$stringPoly = $stringPoly . $widthStart . "," . $y . " ";
				$widthStart = $widthStart + 50;
				}
			//Genera los datos para lineas horizontales cada 50 muertes
			$width = intval($sesion) * 50;
			$heightArray = array();
			$heightStart = 0;
			while ($heightStart <= $height) {
				$heightArray[] = $heightStart;
				$heightStart = $heightStart + 50;
				}
			//Se crea el SVG con ancho del numero de sesiones 50px y el alto del numero de muertes final +5
			echo "<svg height=\"" . $height . "\" width=\"" . $width . "\">";
				//Crea las líneas horizontales cada 50 muertes
				foreach($heightArray as $yLine) {
					echo "<line x1=\"0\" y1=\"" . (intval($height) - intval($yLine)) . "\" x2=\"" . $width . "\" y2=\"" . (intval($height) - intval($yLine)) ."\" />";
					}
				//Polyline de progresión de las muertes
				echo "<polyline points=\"" . $stringPoly . "\"";
				//Marcas verticales para cada sesion de muertes
				$auxColumn = 0;
				foreach($totalSums as $step) {
					echo "<line x1=\"" . $auxColumn . "\" y1=\"" . (intval($step) - 3) . "\" x2=\"" . $auxColumn . "\" y2=\"" . (intval($step) + 3) . "\" />";
				$auxColumn = intval($auxColumn) + 50;
					}
			echo "</svg>";
			?>
		<!--Lleva al historial con todas las muertes donde pueden borrarse en caso de necesidad-->
		<form action="adminmuertes/">
			<input class ="admin" type="submit" value="Panel de administración"></input>
		</form>
	</body>
</html>
